---
name: Modern SaaS Mobile Workspace
colors:
  surface: '#f8f9ff'
  surface-dim: '#d7dae3'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3fc'
  surface-container: '#ebeef7'
  surface-container-high: '#e5e8f1'
  surface-container-highest: '#dfe2eb'
  on-surface: '#181c22'
  on-surface-variant: '#45464d'
  inverse-surface: '#2c3137'
  inverse-on-surface: '#eef1fa'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#516600'
  on-secondary: '#ffffff'
  secondary-container: '#cdf062'
  on-secondary-container: '#566c00'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#07006c'
  on-tertiary-container: '#7073ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#cdf062'
  secondary-fixed-dim: '#b2d349'
  on-secondary-fixed: '#161e00'
  on-secondary-fixed-variant: '#3c4d00'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#f8f9ff'
  on-background: '#181c22'
  surface-variant: '#dfe2eb'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  margin-tablet: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
The design system establishes a high-clarity, kinetic productivity environment tailored for fast-paced modern product teams. The visual tone balances enterprise-grade efficiency with the playful, optimistic edge of next-generation developer and collaboration tools. 

Blending **Minimalism** with focused **Tactile High-Contrast** touches, the interface rejects dense bureaucratic clutter. It relies on a cool, calming background atmosphere contrasted against crisp physical card planes, hyper-legible dark slate typography, and intentional electric neon accents to command instant user focus on active operations and primary calls-to-action.

## Colors
The palette leverages chromatic restraint paired with surgical high-visibility accents:

- **Canvas Background (`#EEF1FA`)**: Soft Periwinkle base provides a tranquil, low-fatigue workspace distinct from stark clinical white or sterile gray.
- **Card Surfaces (`#FFFFFF`)**: Pure crisp white creates physical elevation and structure against the periwinkle background.
- **Primary & Headings (`#0F172A`)**: Dark Midnight Slate ensures AA/AAA contrast ratios for text, primary filled states, and structural icons.
- **Accent Highlight (`#D4F768`)**: Electric Neon Lime serves as the signature interaction trigger for primary CTAs, active indicator pips, floating buttons, and progress completion states. Pair exclusively with `#0F172A` text or icon overlays for contrast compliance.
- **Structural Outlines (`#E2E8F0`)**: Subtle hairline slate for crisp container framing.
- **Domain Category Pills**:
  - *Product*: Sky Blue (`#E0F2FE` background / `#0369A1` label)
  - *Engineering*: Mint (`#DCFCE7` background / `#15803D` label)
  - *Marketing*: Lavender (`#F3E8FF` background / `#7E22CE` label)
  - *Design*: Soft Periwinkle (`#E0E7FF` background / `#4338CA` label)
- **Priority Indicators**:
  - *High*: Coral Red (`#FEE2E2` background / `#B91C1C` label)
  - *Medium*: Warm Amber (`#FEF3C7` background / `#B45309` label)
  - *Low*: Muted Green (`#ECFDF5` background / `#047857` label)

## Typography
Built entirely around **Inter**, the typography leverages tight negative tracking on larger headlines to deliver a modern, precise SaaS presence. 

- Headings use bold and semibold weights (`700` and `600`) with proportional optical leading to avoid collisions in dynamic mobile multi-line titles.
- Body copy relies on standard regular tracking with relaxed line heights (`1.4`–`1.5x`) to preserve effortless scanning during high-density triage sessions.
- Labels, tags, and category indicators leverage uppercase-leaning or high-legibility medium/semibold weights to ensure readability at sizes down to 11px.

## Layout & Spacing
The layout adheres to a strict 8pt base grid with a 4pt sub-grid for tight micro-alignments.

- **Mobile Viewport Structure**: The application operates on a 4-column fluid mobile layout with a fixed `1rem` (16px) outer margin and `1rem` column gutters. 
- **Vertical Rhythm**: Card stacks and section groupings use `space-md` (16px) vertical gaps. Inner card paddings conform to `space-md` (16px) for compact listings and `space-lg` (24px) for focus views.
- **Safe Area Insets**: The bottom content container includes persistent padding bottom (`space-xl` + 64px) to guarantee clean clearance above the fixed mobile floating navigation dock.

## Elevation & Depth
Depth is created by juxtaposing pure `#FFFFFF` surfaces against the `#EEF1FA` periwinkle background, framed by structural low-contrast borders.

- **Level 0 (App Shell)**: `#EEF1FA` flat background canvas.
- **Level 1 (Card & Module Deck)**: `#FFFFFF` surface accompanied by a hairline `1px solid #E2E8F0` border and an ambient, ultra-diffused shadow: `0 2px 8px -2px rgba(15, 23, 42, 0.04), 0 1px 4px -1px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Floating Sheets & Bottom Navigation)**: `#FFFFFF` surface with `1px solid #E2E8F0` and lifted shadow: `0 8px 24px -4px rgba(15, 23, 42, 0.08)`.
- **Level 3 (Modals & Popovers)**: `#FFFFFF` surface elevated over a 40% `#0F172A` backdrop blur overlay, with a directional drop shadow: `0 20px 32px -8px rgba(15, 23, 42, 0.16)`.

## Shapes
The system employs a balanced, contemporary rounded corner scale (`roundedness: 2`).

- **Primary Cards & Containers**: `1rem` (16px) corner radius creates a friendly yet structured modular feel.
- **Interactive Controls (Inputs, Buttons)**: `0.75rem` (12px) for crisp tactile interaction.
- **Tags, Badges, and Micro-Pills**: Full pill geometry (`9999px`) to emphasize distinct categorical metadata and priority tags.
- **Bottom Navigation Dock**: `1.25rem` (20px) top corners or full floating pill capsule.

## Components

### Buttons
- **Primary CTA**: Background `#D4F768`, foreground `#0F172A`, font weight `600`, radius `12px`, height `48px`. Pressed state shifts tone to `#C3E853` with scale down to `0.98`.
- **Secondary**: Background `#0F172A`, foreground `#FFFFFF`, height `48px`, radius `12px`.
- **Tertiary / Ghost**: Transparent fill, foreground `#0F172A`, subtle border `#E2E8F0` or borderless for action bars.

### Cards
- Set on `#FFFFFF` with `16px` border radius, `1px solid #E2E8F0`, and ambient low-opacity shadow. Inner padding is `16px`. Internal divider lines, when needed, share the `#E2E8F0` token.

### Tags & Category Pills
- Height `24px`, full capsule radius (`9999px`), horizontal padding `10px`, font `label-sm`.
- Render with pastel background matched with saturated dark ink (e.g., Mint `#DCFCE7` with text `#15803D`).
- Priority pills feature a `6px` circular status pip placed to the left of the label.

### Inputs & Form Fields
- Height `48px`, background `#FFFFFF`, border `1px solid #E2E8F0`, corner radius `12px`, padding `0 16px`. Active focus state transitions border to `#0F172A` with an ambient `0 0 0 3px rgba(212, 247, 104, 0.45)` neon focus ring.

### Checkboxes & Radio Controls
- Base size `20px` with `6px` radius (checkbox) or circular (radio). Unchecked: `#FFFFFF` with `1.5px solid #CBD5E1`. Checked: filled `#0F172A` with a crisp `#D4F768` checkmark glyph.

### Mobile Bottom Navigation Bar
- Fixed dock spanning the bottom viewport, backed by `#FFFFFF` with `1px solid #E2E8F0` top border and elevation Level 2.
- Height is `64px` plus safe area inset.
- Displays 5 evenly spaced touch targets (min `44x44px`):
  1. **Projects** (`FolderKanban` icon)
  2. **Tasks** (`CheckSquare` icon)
  3. **Calendar** (`Calendar` icon)
  4. **Insights** (`BarChart3` icon)
  5. **Team** (`Users` icon)
- Inactive state: `#64748B` icon with `label-sm` text. Active state: `#0F172A` icon and text, flanked by an active mini dot or indicator strip rendered in `#D4F768`.