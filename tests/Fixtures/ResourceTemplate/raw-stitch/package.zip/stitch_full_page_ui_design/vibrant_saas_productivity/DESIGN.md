---
name: Vibrant SaaS Productivity
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#784b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#996100'
  on-tertiary-container: '#ffeedd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
  stat-metric:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies modern collaborative SaaS productivity: crisp, structured, approachable, and energized. The aesthetic merges contemporary enterprise clarity with vibrant high-utility product interfaces.

### Core Philosophy & Visual Voice
- **Tone:** Optimistic, clear, hyper-efficient, and polished.
- **Visual Style:** Modern Corporate meets Soft Tactile SaaS. Crisp snow-white card surfaces elevate above a cool-tinted slate backdrop (`#F4F7FC`), grounded with hair-thin borders (`#E2E8F0`), diffused multi-step shadows, and richly saturated status badges.
- **Target Audience:** Modern cross-functional teams, agile product squads, and fast-paced knowledge workers who require maximum data density without visual fatigue.
- **Emotional Intent:** Reduces cognitive friction, imparts control and calm momentum, and celebrates task completion with joyful chromatic accents.

## Colors

The palette balances clean foundational neutrals with high-chroma functional accents to establish clear data hierarchy and status awareness.

### Color Architecture
- **Primary Electric Blue (`#2563EB` / `#3B82F6`):** Drives primary actions, active navigation states, key metric highlights, and prominent callouts.
- **Success Emerald (`#10B981`):** Represents completed workflows, positive percentage trajectories, and online availability.
- **Warning Amber (`#F59E0B`):** Denotes in-progress tasks, medium-priority milestones, and pending actions.
- **Critical Coral (`#EF4444`):** Flags negative differentials, overdue tasks, and high-urgency alerts.
- **Accent Violet (`#8B5CF6`):** Highlights team structures, collaborative counters, and specialized category tags.
- **Canvas Base (`#F4F7FC`):** A soft, cool slate-tinted white that eliminates harsh glare while providing clear contrast against pure white cards (`#FFFFFF`).

## Typography

The typography pairs **Plus Jakarta Sans** for expressive, geometric headers with **Inter** for readable body and numerical data.

- **Header Hierarchy:** Plus Jakarta Sans provides geometric warmth and executive clarity. Letter spacing on titles sits tight (`-0.02em`) to maintain punchy presence.
- **Functional Body:** Inter handles micro-copy, metadata timestamps, data tables, and user labels with tabular lining numerals where metrics appear.
- **Weight Strategy:** Numerical metric readouts utilize bold weights (`700` and `800`) to enable immediate visual scanning across dashboard boards.

## Layout & Spacing

A disciplined 8px modular baseline governs all spatial relationships across the canvas.

### Layout Rhythm & Structure
- **Global Structure:** Two-tier shell architecture consisting of an 80px fixed mini-sidebar or 240px expanded navigation rail on desktop, pairing with a 12-column fluid grid in the central workspace.
- **Card Padding:** Standard cards enforce an internal padding of `1.25rem` (`20px`), while condensed metric widgets use `1rem` (`16px`).
- **Responsive Behavior:**
  - *Desktop (≥1200px):* Full 12-column dashboard layout; 4-column metric band; multi-column Kanban rails.
  - *Tablet (768px - 1199px):* Metrics reflow into a 2x2 grid; sidebar collapses to an icon rail; Kanban columns switch to horizontal scroll snap.
  - *Mobile (<768px):* Single-column flow; navigation transitions to an off-canvas drawer; gutters reduce to `1rem`.

## Elevation & Depth

Visual hierarchy is maintained through subtle, light-permeable layering instead of dark drop shadows.

### Elevation Levels
- **Layer 0 (Canvas Base):** Flat slate background `#F4F7FC`.
- **Layer 1 (Card & Container Surface):** Pure white `#FFFFFF` paired with an ultra-fine border `1px solid rgba(226, 232, 240, 0.8)` and a feathered ambient shadow: `0 1px 3px rgba(15, 23, 42, 0.04), 0 4px 12px rgba(15, 23, 42, 0.03)`.
- **Layer 2 (Interactive Floating & Draggable Cards):** Kanban cards and hovered widgets lift with `0 8px 24px rgba(37, 99, 235, 0.08), 0 2px 6px rgba(15, 23, 42, 0.04)`.
- **Layer 3 (Overlays, Modals & Menus):** Clean crisp white surface with `0 20px 40px rgba(15, 23, 42, 0.12)` and backdrop blur `blur(8px)` on supporting overlays.

## Shapes

The interface embraces a balanced curvature model that combines professional precision with modern software softness.

- **Primary Radius (`0.75rem` / `12px`):** Standard for interior cards, metric containers, and task boards.
- **Outer Frame Radius (`1rem` / `16px`):** Applied to major dashboard canvas panels and large section wrappers.
- **Component Radius (`0.5rem` / `8px`):** Used for input fields, buttons, drop-down menus, and micro-cards.
- **Badge & Avatar Radius (`9999px` / Pill):** Applied to status badges, metric indicators, pill buttons, and user avatars.

## Components

### Buttons
- **Primary Action:** Solid electric blue background (`#2563EB`) with crisp white text, bold font-weight (`600`), 8px border radius, and subtle glow on hover (`box-shadow: 0 4px 14px rgba(37, 99, 235, 0.35)`).
- **Secondary / Ghost:** Soft blue background (`#EFF6FF`) with primary blue label (`#2563EB`), or pure white with border `1px solid #E2E8F0`. Hover shifts background to `#F1F5F9`.
- **Pill Link Button:** Centered icon with trailing directional arrow, high-contrast text, designed for navigation widgets and CTAs.

### Badges & Status Chips
- **Pill Construction:** Full border radius with generous horizontal padding (8px-12px) and height of 24px.
- **Status Variants:**
  - *Success / Low:* Light emerald tint (`#ECFDF5`), deep emerald text (`#059669`).
  - *Warning / Medium:* Light amber tint (`#FFFBEB`), warm amber text (`#D97706`).
  - *Danger / High:* Light rose tint (`#FEF2F2`), strong red text (`#DC2626`).
  - *Active Count:* Semi-transparent gray-slate (`#F1F5F9`) with slate label (`#475569`).

### Stat Metric Cards
- White background, light outline, rounded corners. Features a circular leading icon badge tinted in the metric's functional hue (48px circle, 20% opacity background), large numerical metric display (`28px`), and an inline trend pill displaying percentage change.

### Kanban Task Cards
- Compact white card surface, 1px border (`#E2E8F0`), containing:
  - Top row: Task name and priority chip.
  - Middle row: Due date with calendar micro-icon.
  - Bottom row: User avatar (28px circle) with assignment indicator.

### Progress & Visualization Bars
- 6px to 8px rounded track with light slate-blue background (`#E2E8F0`).
- Progress fills use saturated gradient fills (e.g., `#2563EB` to `#60A5FA`).

### Form Controls & Inputs
- **Search & Text Fields:** 40px height, light background (`#F8FAFC`), border `1px solid #E2E8F0`, interior placeholder text `#94A3B8`. Focus state introduces a 2px blue ring (`#2563EB`) with zero layout shift.